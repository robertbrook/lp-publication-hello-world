Hello World Sample Publication
==============================

This is the sample 'Hello World' publication for Little Printer. It has been prepared exclusively for the BERG Hackday, and should be treated as 'beta', and subject to change before launch.




